import java.util.List;

class Author<T> extends ArrayList<T> {
}