import java.util.List;

class BookList<T> extends ArrayList<T> {

}