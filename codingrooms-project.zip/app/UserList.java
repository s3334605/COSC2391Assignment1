import java.util.List;

class UserList<User> extends ArrayList<T>{

}