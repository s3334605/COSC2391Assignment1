class Daintree {
    private BookList<T> bookList;
    private UserList<T> userList;

    public static void main(String[] args) {
        
    }
}