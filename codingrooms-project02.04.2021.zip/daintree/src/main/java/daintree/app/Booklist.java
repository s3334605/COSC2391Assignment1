package daintree.app;

public class Booklist {
	
	private Book[] bookList;
    private String name;

    public Booklist() {
        name = new String("Booklist");
        bookList = new Book[1];
        bookList[0] = new Book();
    }

    public Booklist(String name){
        this.name = name;
        bookList = new Book[1];
        bookList[0] = new Book();
    }
    
    public Book[] getbookList() {
    	return bookList;
    }

    public void setBookList(Book[] bookList) {
        this.bookList = bookList;
    }

    public void addBook(Book newBook) {
        if (newBook.getNumberAvailable() > 1 || newBook.getEbookAvailable()) {
            if (bookList[0].getTitle().isEmpty()) {
                bookList[0] = newBook;
            } else {
                Book[] newbookList = new Book[bookList.length + 1];
                for (int i = 0; i < bookList.length; i++) {
                    newbookList[i] = bookList[i];
                }
                bookList = newbookList;
                bookList[bookList.length - 1] = newBook;
            }
        }
    }

    public void removeBookFromBooklist(int selection) {
        int addCount = 0;
        int index = 0;
        boolean inRange = bookList.length >= selection;
        if (inRange) {
            if (bookList.length > 1) {
                Book[] newbookList = new Book[bookList.length - 1];
                bookList[selection - 1] = new Book();
                for (Book book:bookList) {
                    if(!book.getTitle().isEmpty()){
                    newbookList[addCount] = bookList[index];
                    addCount++;
                    } 
                    index++;
                }
                bookList = newbookList;
            } else {
                bookList = new Book[1];
            }
        }
    }
    
    public Book getBook(int index) {
    	return bookList[index];
    }
    
    public Booklist searchMatch(String input) {
        Booklist matches = new Booklist();
        if (!input.isEmpty()) {
            for(Book book:bookList) {
                //If it matches the title and it's either an eBook or there are physical copies available
                if(book.containsTitle(input) && (book.getNumberAvailable() > 0 || book.getEbookAvailable())) {
                    matches.addBook(book);
                }
            }
        }
        return matches;
    }

    //for this application, the exact title is the id of the object, in other applications, an ID variable would by the unique identifier
    public int searchIndex(String title) {
        int searchIndex = -1;
        int index = 0;
        for(Book book: bookList) {
            if(book.containsTitle(title)){
                searchIndex = index;
            }
            index++;
        }
        return searchIndex;
    }

    public void printBooklist() {
        int index = 1;
        if(bookList[0].getTitle().isEmpty()) {
            System.out.println(name + " is empty");
        } else {
            for(Book book:bookList) {
            System.out.println(index + ". " + book.getTitle());
            index++;
            }
        }
    }
}
