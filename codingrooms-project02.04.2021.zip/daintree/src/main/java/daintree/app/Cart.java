package daintree.app;

public class Cart extends Booklist {
    private int[] quantities;

    public Cart() {
        super("Cart");
        quantities = new int[1];
        quantities[0] = 0;
    }

    public void addBook(Book book, boolean isEbook) {
        int index = searchIndex(book.getTitle());
        //index -1, book not found in list
        if(index == -1) {
                int newQuantity = book.getNumberAvailable();
                if(isEbook) {
                    newQuantity = -1;    
                }
                super.addBook(book);
                int newLength = super.getbookList().length;
                int[] newQuantities = new int[newLength];
                //fill the array
                for (int i = 0; i < quantities.length; i++) {
                    newQuantities[i] = quantities[i];
                }
                newQuantities[newLength - 1] = newQuantity;
                quantities = newQuantities;                
        } else {
            //If not adding more than available and that book is not an eBook (ebook quantity is -1)
        	if(quantities[index] < book.getNumberAvailable() && !isEbook) {
	            {
	                quantities[index]++;
	            }
        	} 
        }
    }

    public void removeBookFromBooklist(int selection) {
        int index = selection - 1;
        //selection is within the range of the input
        if(selection >= 0 && selection <= getbookList().length) {
            //If only one is in the cart or if it's an eBook, it needs to be removed
            if(quantities[index] == 1 || quantities[index] == -1) {
                super.removeBookFromBooklist(selection);
                int addCount = 0;
                int newLength = super.getbookList().length;
                //if the cart with one less item has a length greater than zero
                if (newLength > 1) {
                    int[] newQuantities = new int[newLength];
                    for (int i = 0; i < newLength; i++) {
                        //if the index is equal to the selection index or is at the end of the list
                        if(i == index){
                        addCount++;
                        }
                        newQuantities[i] = quantities[i+addCount];
                    }
                    quantities = newQuantities;
                } else {
                    quantities[0] = 0;
                }
            } 
            //if quantity is greater than 1
            else {
                quantities[index]--;
            }
        }
    }
    
    public double grandTotal() {
    	double total = 0;
    	for(int i = 0; i < quantities.length;i++) {
    		if(quantities[i] == -1) {
    			total += 8;
    		} else {
    			total += quantities[i]*50;
    		}
    	}
    	return total;
    }
    
    public int quantityTotal() {
    	int total = 0;
    	for (int i : quantities) {
    		total += i;
    	}
    	return total;
    }

	public int getQuantity(int index) {
		return quantities[index];
	}
	
	public void setQuantity(int i, int value) {
		quantities[i] = value;
	}

    public void setQuantities(int[] quantities) {
        this.quantities = quantities;
    }

}