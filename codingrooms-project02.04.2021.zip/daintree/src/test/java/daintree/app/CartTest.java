package daintree.app;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Unit test for the Cart Class
 */
public class CartTest 
{
    public Cart cartTestEmpty() {
        Cart cart = new Cart();
        return cart;
    }

    public Cart cartTestFull() {
        Book book1 = new Book("Absolute Java", "Savitch", 5, true);
	    Book book2 = new Book("JAVA: How to Program", "Deitel & Deital", 0, true);
	    Book book3 = new Book("Computing Concepts with JAVA 8 Essentials", "Horstman", 5, false);
	    Book book4 = new Book("Java Software Solutions", "Lewis & Loftus", 5, false);
	    Book book5 = new Book("Java Program Design", "Cohoon & Davidson", 1, true);
        Book[] books = new Book[5];
        books[0] = book1;
        books[1] = book2;
        books[2] = book3;
        books[3] = book4;
        books[4] = book5;
        Cart cart = new Cart();
        cart.setBookList(books);
        int[] quantities = {1, -1, 3, 2, -1};
        cart.setQuantities(quantities);
        return cart;
    }

    @Test
    public void searchMatchTest() {
        Cart full = cartTestFull();
        String input1 = new String("java");
        String input2 = new String("am");
        String input3 = new String("the");
        String input4 = new String();
        assertEquals(full.searchMatch(input1).getbookList().length, 5);
        assertEquals(full.searchMatch(input2).getbookList().length, 2);
        assertEquals(full.searchMatch(input3).getbookList().length, 1);
        assertEquals(full.searchMatch(input4).getbookList().length, 1);
    }

    @Test
    public void addBookTest(){
        Cart empty = cartTestEmpty();
        assertEquals(empty.getbookList().length, 1);
        Cart full = cartTestFull();
        Book book1 = new Book("Absolute Java", "Savitch", 5, true);
	    Book book2 = new Book("JAVA: How to Program", "Deitel & Deital", 0, true);
	    Book book3 = new Book("Computing Concepts with JAVA 8 Essentials", "Horstman", 5, false);
	    Book book4 = new Book("Java Software Solutions", "Lewis & Loftus", 5, false);
	    Book book5 = new Book("Java Program Design", "Cohoon & Davidson", 1, true);

        System.out.println("Empty cart!");
        empty.printBooklist();
        empty.addBook(book1, false);
        System.out.println("Book1 added.");
        empty.printBooklist();
        empty.addBook(book2, true);
        System.out.println("Book2 added.");
        empty.printBooklist();
        empty.addBook(book3, false);
        System.out.println("Book3 added.");
        empty.printBooklist();
        empty.addBook(book4, false);
        System.out.println("Book4 added.");
        empty.printBooklist();
        empty.addBook(book5, false);
        System.out.println("Book5 added.");
        empty.printBooklist();
        assertEquals(full.getbookList().length, empty.getbookList().length);
    }

    @Test
    public void removeBookFromBooklistTest() {
        Cart full = cartTestFull();
        int startLength = full.getbookList().length;
        Cart empty =  cartTestEmpty();
        int emptyLength = empty.getbookList().length;
        full.removeBookFromBooklist(1);
        //testing did was the book removed from the list
        assertEquals(full.getbookList().length, (startLength - 1));

        int quantity = full.getQuantity(1);
        full.removeBookFromBooklist(2);
        //testing whether, if the item has an availability greater than 1, will it reduce the quantity by 1 if removed.
        assertEquals(full.getQuantity(1), quantity - 1);
        //testing whether, since the quantity was greater than one, it wasn't removed
        assertEquals(full.getbookList().length, (startLength - 1));

        System.out.println("Before:");
        full.printBooklist();
        full.removeBookFromBooklist(4);
        //testing if an ebook was removed
        System.out.println("After:");
        full.printBooklist();
        assertEquals(full.getbookList().length, (startLength - 2));

        empty.removeBookFromBooklist(2);
        //testing for errors if trying to remove a book beyong the bounds of a cart on empty cart
        assertEquals(empty.getbookList().length, 1);
    }

    @Test 
    public void grandTotalTest() {
        Cart cart = cartTestFull();
        System.out.println(cart.grandTotal());
        assertEquals(cart.grandTotal(), 316.0, 0.01);
    }
}