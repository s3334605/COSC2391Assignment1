package daintree.app;

import static org.junit.Assert.*;

import org.junit.Test;
/**
 * Unit test for the Booklist Class
 **/
public class BooklistTest 
{
    public Booklist booklistTestEmpty() {
        Booklist booklist = new Booklist();
        return booklist;
    }

    public Booklist booklistTestFull() {
        Book book1 = new Book("Absolute Java", "Savitch", 5, true);
	    Book book2 = new Book("JAVA: How to Program", "Deitel & Deital", 0, true);
	    Book book3 = new Book("Computing Concepts with JAVA 8 Essentials", "Horstman", 5, false);
	    Book book4 = new Book("Java Software Solutions", "Lewis & Loftus", 5, false);
	    Book book5 = new Book("Java Program Design", "Cohoon & Davidson", 1, true);
        Book[] books = new Book[5];
        books[0] = book1;
        books[1] = book2;
        books[2] = book3;
        books[3] = book4;
        books[4] = book5;
        Booklist booklist = new Booklist();
        booklist.setBookList(books);
        return booklist;
    }

    @Test
    public void searchMatchTest() {
        Booklist full = booklistTestFull();
        String input1 = new String("java");
        String input2 = new String("am");
        String input3 = new String("the");
        String input4 = new String();
        assertEquals(full.searchMatch(input1).getbookList().length, 5);
        assertEquals(full.searchMatch(input2).getbookList().length, 2);
        assertEquals(full.searchMatch(input3).getbookList().length, 1);
        assertEquals(full.searchMatch(input4).getbookList().length, 1);
    }

    @Test
    public void addBookTest(){
        Booklist empty = booklistTestEmpty();
        assertEquals(empty.getbookList().length, 1);
        Booklist full = booklistTestFull();
        Book book1 = new Book("Absolute Java", "Savitch", 5, true);
	    Book book2 = new Book("JAVA: How to Program", "Deitel & Deital", 0, true);
	    Book book3 = new Book("Computing Concepts with JAVA 8 Essentials", "Horstman", 5, false);
	    Book book4 = new Book("Java Software Solutions", "Lewis & Loftus", 5, false);
	    Book book5 = new Book("Java Program Design", "Cohoon & Davidson", 1, true);
        empty.addBook(book1);
        empty.addBook(book2);
        empty.addBook(book3);
        empty.addBook(book4);
        empty.addBook(book5);
        assertEquals(full.getbookList().length, empty.getbookList().length);
    }

    @Test
    public void removeBookFromBooklistTest() {
        Booklist full = booklistTestFull();
        int startLength = full.getbookList().length;
        full.removeBookFromBooklist(1);
        assertEquals(full.getbookList().length, startLength - 1);
        Booklist empty = booklistTestEmpty();
        int emptyLength = empty.getbookList().length;
        full.removeBookFromBooklist(2);
        empty.removeBookFromBooklist(2);
        assertEquals(full.getbookList().length, startLength - 2);
        assertEquals(empty.getbookList().length, 1);
        full.removeBookFromBooklist(4);
        assertEquals(full.getbookList().length, startLength - 2);
    }
    
}