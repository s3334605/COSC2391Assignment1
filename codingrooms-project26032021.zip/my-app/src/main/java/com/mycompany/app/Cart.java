class Cart {
    private Book[] cart;

    public Cart() {
        cart = new Book[1];
    }

    public void addBook(Book newBook) {
        Book[] newCart = new Book[cart.length + 1];
        for (int i = 0; i < cart.length; i++) {
            newCart[i] = cart[i];
        }
        cart = newCart;
        cart[cart.length - 1] = newBook;
    }

    public void removeBookFromCart(int selection) {
        int addCount = 0;
        int index = 0;
        if (cart.length > 1) {
            Book[] newCart = new Book[cart.length - 1];
            cart[selection - 1] = new Book();
            for (Book:cart) {
                if(!cart[index].getTitle().isEmpty()){
                newCart[addcart] = cart[index];
                addcart++;
                } 
                index++;
            }
            cart = newCart;
        } else {
            cart = new Book[1];
        }
    }

}