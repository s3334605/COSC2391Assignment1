import java.util.Scanner;

class BookStore extends Exceptions{

    private Cart catalogue;

    public BookStore() {
        catalogue.addBook(new Book("Absolute Java", "Savitch", 5, true));
        catalogue.addBook(new Book ("JAVA: How to Program", "Deitel & Deital", 0, true));
        catalogue.addBook(new Book ("Computing Concepts with JAVA 8 Essentials", "Horstman", 5, false));
        catalogue.addBook(new Book ("Java Software Solutions", "Lewis & Loftus", 5, false));
        catalogue.addBook(new Book ("Java Program Design", "Cohoon & Davidson", 1, true));
        }
    
    public static void main(String[] args) {
        BookStore store = new BookStore();
    }
    
}
