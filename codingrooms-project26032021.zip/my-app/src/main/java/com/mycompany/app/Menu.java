class Menu {
    
}

public void printMenu() {
        System.out.println("Welcome to Daintree!\n"+ 
        "Choose an option\n" +
        "1. Add a book to shopping cart\n" +
        "2. View shopping cart\n"+
        "3. Remove a book from shopping cart\n" +
        "4. Checkout\n" +
        "5. List all books\n" +
        "0. Quit\n");
        System.out.print("Please make a selection: ");
    }